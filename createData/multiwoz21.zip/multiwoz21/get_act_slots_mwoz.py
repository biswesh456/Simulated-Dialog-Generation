#!/usr/bin/env python
# coding: utf-8

# In[ ]:


from transformers import BertTokenizer, BertModel, BertForMaskedLM
tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
model = BertModel.from_pretrained('bert-base-uncased')
model.to('cuda');
model.eval();


# In[6]:


import json
with open("dialogue_acts.json") as f:
    dialog_acts = json.load(f)
    
with open("data.json") as f:
    data = json.load(f)
    
all_slot_vals = {}
all_actslots = {}
for key in dialog_acts:
    dd_full = data[key+".json"]["log"]
    dd_text = [x["text"] for x in dd_full]
    dd = {str(int((i+1)/2)):x for i,x in enumerate(dd_text) if i%2==1}
    dd_acts = dialog_acts[key]
    for ind in dd_acts:
        if ind not in dd:
            continue
        actslots = dd_acts[ind]
        utt = dd[ind]
        if not isinstance(actslots, dict):
            continue
        for act in actslots:
            slots = actslots[act]
            for slot in slots:
                slot_val = slot[1]
                if slot_val in all_slot_vals:
                    all_slot_vals[slot_val] += 1
                else:
                    all_slot_vals[slot_val] = 1
                newkey = act + "_" + slot[0]
                if newkey in all_actslots:
                    all_actslots[newkey].append(utt)
                else:
                    all_actslots[newkey] = [utt]
    

with open("dialogue_acts.json") as f:
    dialog_acts = json.load(f)
    
with open("data.json") as f:
    data = json.load(f)
    
all_actslots = {}
for key in dialog_acts:
    dd_full = data[key+".json"]["log"]
    dd_text = [x["text"] for x in dd_full]
    dd = {str(int((i+1)/2)):x for i,x in enumerate(dd_text) if i%2==1}
    dd_acts = dialog_acts[key]
    for ind in dd_acts:
        if ind not in dd:
            continue
        actslots = dd_acts[ind]
        utt = dd[ind]
        if not isinstance(actslots, dict):
            continue
        for act in actslots:
            slots = actslots[act]
            for slot in slots:
                slot_type = slot[0]
                slot_val = slot[1]
                if slot_val in all_slot_vals and all_slot_vals[slot_val]>20:
                    a=2
                else:
                    utt = utt.replace(slot_val, slot_type)
                newkey = act + "_" + slot_type
                if newkey in all_actslots:
                    all_actslots[newkey].append(utt)
                else:
                    all_actslots[newkey] = [utt]
    
# In[7]:


def get_embedding(batch):
    tokens = [tokenizer.tokenize(x) for x in batch]
    token_ids = [tokenizer.convert_tokens_to_ids(x) for x in tokens]
    token_ids = [tokenizer.build_inputs_with_special_tokens(x) for x in token_ids] 
    lengths = [len(x) for x in token_ids]
    maxlen = max(lengths)

    batch_sentids = [x + [0]*(maxlen-ll) for x,ll in zip(token_ids, lengths)]
    batch_sentids = torch.Tensor(batch_sentids).long().cuda()
    batch_mask = [[int(x > 0) for x in sent_id] for sent_id in batch_sentids]
    batch_mask = torch.Tensor(batch_mask).int().cuda()        
    with torch.no_grad():
        output, pooled = model(batch_sentids,  attention_mask=batch_mask)
    return pooled


# In[10]:


import torch
import sys

representative1 = {}
representative2 = {}
for act_slot in all_actslots:
    print(act_slot)
    utts =  all_actslots[act_slot]
    batch_size = 100
    num_batches = int(len(utts)/batch_size)
    all_embeds = torch.zeros(len(utts), 768).cuda()
    for i in range(num_batches):
        start = i*batch_size
        stop = (i+1)*batch_size
        batch = utts[start:stop]
        bembeds = get_embedding(batch)
        all_embeds[start:stop] = bembeds
        print("%d/%d " %(i, num_batches), end='\r')
    start = num_batches*batch_size
    batch = utts[start:]
    bembeds = get_embedding(batch)
    all_embeds[start:] = bembeds

    norm_all = (all_embeds**2).sum(1, keepdim=True)**.5
    normalized_embeds = all_embeds/norm_all
    mean_embed = normalized_embeds.mean(0, keepdim=True)
    sims = (normalized_embeds*mean_embed).sum(1)
    val, ind = sims.max(0)
    representative1[act_slot] = utts[ind]
    print(utts[ind])
    

    mean_embed = all_embeds.mean(0, keepdim=True)
    sims = (all_embeds*mean_embed).sum(1)
    norm_all = (all_embeds**2).sum(1)**.5
    norm_mean = (mean_embed**2).sum()**.5
    sims = sims/(norm_all*norm_mean)
    val, ind = sims.max(0)
    representative2[act_slot] = utts[ind]
    print(utts[ind])
    sys.stdout.flush()    

import json
with open('actslots1.json', 'w') as fp:
    json.dump(representative1, fp)
with open('actslots2.json', 'w') as fp:
    json.dump(representative2, fp)


# In[ ]:




